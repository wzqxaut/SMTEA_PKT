function [BestChart, BestFitness, farmlayout] = SMTEA_PKT(popsize, wf, iterations)
K = numel(wf.turbine_num);
D = wf.turbine_num;
field = wf.rows * wf.cols;
site = setdiff(1 : field, wf.NA_loc);

[stageD, stageOrder] = sort(D, 'ascend');
stageIter = stage_budget(iterations, stageD);

popu = cell(1, K);
popuFit = cell(1, K);
popuPower = cell(1, K);
evaluated = cell(1, K);

BestChart = zeros(iterations, K);
BestFitness = zeros(1, K);
farmlayout = zeros(K, field);

for stageId = 1 : K
    taskId = stageOrder(stageId);

    if stageId == 1
        [popu{taskId}, ~, popuFit{taskId}, popuPower{taskId}, ~] = windfarm_init(popsize, D(taskId), wf, taskId);
    else
        sourceId = stageOrder(stageId - 1);
        [popu{taskId}, popuFit{taskId}, popuPower{taskId}] = soft_inherit( ...
            popu{sourceId}, popuFit{sourceId}, popuPower{sourceId}, popsize, D(taskId), wf, taskId, site);
    end

    evaluated{taskId} = layout_key(popu{taskId});
    [BestFitness(taskId), bestId] = max(popuFit{taskId});
    farmlayout(taskId, :) = gene_layout_by_indices(wf, popu{taskId}(bestId, :));
    BestChart(1, taskId) = BestFitness(taskId) / wf.power_total(taskId);

    stagnation = 0;
    fprintf('stage:%d task:%d pop:%d iter:%d\n', stageId, taskId, popsize, stageIter(stageId));

    for iter = 2 : stageIter(stageId)
        lastBest = BestFitness(taskId);
        para = social_parameter(popu{taskId}, D(taskId), iter / stageIter(stageId), stagnation, field);

        child = social_offspring(popu{taskId}, popuFit{taskId}, popuPower{taskId}, wf, D(taskId), para, site);
        child = windfarm_constraint(child, wf.NA_loc, D(taskId), 1, field);
        [child, evaluated{taskId}] = remove_seen(child, evaluated{taskId});

        if isempty(child)
            childFit = zeros(0, 1);
            childPower = zeros(0, D(taskId));
        else
            [childFit, childPower, ~] = wf_fitness(wf, child, taskId);
        end

        [popu{taskId}, popuFit{taskId}, popuPower{taskId}] = environmental_selection( ...
            popu{taskId}, popuFit{taskId}, popuPower{taskId}, child, childFit, childPower, para.keep);

        [BestFitness(taskId), bestId] = max(popuFit{taskId});
        farmlayout(taskId, :) = gene_layout_by_indices(wf, popu{taskId}(bestId, :));
        BestChart(iter, taskId) = BestFitness(taskId) / wf.power_total(taskId);
        stagnation = stagnation_update(BestFitness(taskId), lastBest, stagnation);

        if iter == 2 || mod(iter, 10) == 0 || iter == stageIter(stageId)
            fprintf('stage:%d task:%d iter:%d eta: %.12f\n', stageId, taskId, iter, BestChart(iter, taskId));
        end
    end

    BestChart(stageIter(stageId) + 1 : iterations, taskId) = BestChart(stageIter(stageId), taskId);
end
end

%% Task-level resource allocation
function stageIter = stage_budget(iterations, stageD)
stageIter = iterations * ones(1, numel(stageD));
if numel(stageD) > 1
    rho = 0.4;
    lambda = 0.1;
    for stageId = 2 : numel(stageD)
        raw = iterations * rho * (stageD(stageId) / stageD(2)) * (1 + lambda * (stageId - 2));
        stageIter(stageId) = max(10, 10 * round(raw / 10));
    end
end
stageIter(1) = iterations;
end

%% Progressive knowledge transfer
function [popu, popuFit, popuPower] = soft_inherit(sourcePopu, sourceFit, sourcePower, N, D, wf, taskId, site)
[~, sourceBestId] = max(sourceFit);
sourceBest = legal(sourcePopu(sourceBestId, :), wf);
sourceD = numel(sourceBest);
extraD = max(0, D - sourceD);
weakSite = weak_part(sourcePower(sourceBestId, :), sourceBest, sourceD);

popu = zeros(N, D);
for i = 1 : N
    dropNum = mod(i - 1, extraD + 1);
    inheritedSite = setdiff(sourceBest, weakSite(1 : dropNum), 'stable');
    popu(i, :) = complete_layout(inheritedSite, site, site, D, 1 / D);
end

popu = windfarm_constraint(popu, wf.NA_loc, D, 1, wf.rows * wf.cols);
popu = unique_inherit(popu, N, D, sourceBest, weakSite, extraD, site);
[popuFit, popuPower, ~] = wf_fitness(wf, popu, taskId);
end

%% Layer-wise social evolution
function child = social_offspring(popu, popuFit, popuPower, wf, D, para, site)
Layer = social_layer(popuFit);
upPop = legal(popu(Layer.upper, :), wf);
socialPop = legal(popu(Layer.social, :), wf);
midLowPop = legal(popu([Layer.middle; Layer.lower], :), wf);
rareSite = rare_site(popu, site);

child = zeros(size(popu, 1), D);
for i = 1 : size(popu, 1)
    layerId = Layer.layer(i);
    parent = complete_layout(legal(popu(i, :), wf), site, site, D, 1 / D);
    refPop = choose_reference(popu, Layer, layerId, D, wf, site);
    weakSite = weak_part(popuPower(i, :), parent, D);
    releaseSite = weak_replace(parent, refPop, weakSite, para.move(layerId));
    baseSite = setdiff(parent, releaseSite, 'stable');
    sitePool = layer_site_pool(layerId, parent, refPop, upPop, socialPop, midLowPop, rareSite, site);
    child(i, :) = complete_layout(baseSite, sitePool, site, D, para.rand(layerId));
end
end

function Layer = social_layer(popuFit)
N = numel(popuFit);
[~, order] = sort(popuFit, 'descend');
upperNum = max(1, ceil(sqrt(N)));
middleNum = max(1, ceil((N - upperNum) / 3));

Layer.upper = order(1 : upperNum);
Layer.middle = order(upperNum + 1 : upperNum + middleNum);
Layer.lower = order(upperNum + middleNum + 1 : N);
Layer.social = order(1 : upperNum + middleNum);
Layer.layer = zeros(N, 1);
Layer.layer(Layer.upper) = 1;
Layer.layer(Layer.middle) = 2;
Layer.layer(Layer.lower) = 3;
end

function refPop = choose_reference(popu, Layer, layerId, D, wf, site)
if layerId == 1
    ids = Layer.upper;
elseif layerId == 2
    ids = [Layer.upper; Layer.middle];
else
    ids = Layer.middle;
end

refPop = complete_layout(legal(popu(ids(randi(numel(ids))), :), wf), site, site, D, 1 / D);
end

function sitePool = layer_site_pool(layerId, parent, refPop, upPop, socialPop, midLowPop, rareSite, site)
if layerId == 1
    sitePool = [refPop, upPop];
elseif layerId == 2
    sitePool = [setdiff(refPop, parent, 'stable'), socialPop, upPop];
else
    sitePool = [rareSite, midLowPop];
end
end

function releaseSite = weak_replace(parent, refPop, weakSite, move)
unsupported = setdiff(parent, refPop, 'stable');
candidate = unique([weakSite(ismember(weakSite, unsupported)), weakSite], 'stable');
move = min([move, numel(candidate), numel(parent) - 1]);
releaseSite = candidate(1 : move);
end

%% Social pressure-guided parameter adaptation
function para = social_parameter(popu, D, progress, stagnation, field)
N = size(popu, 1);
mu = (1 : 3) / 3;
pressure = social_pressure(popu, field);
feedback = stagnation / (stagnation + 1);
flow = pressure + feedback;

para.move = max(1, ceil(sqrt(D) .* mu .* (1 + flow) / 2));
para.rand = min(1 / sqrt(D), mu .* flow + (1 - progress) / D);
para.keep = max(ceil(sqrt(N)), ceil(N / (1 + flow)));
end

%% Resource redistribution
function [popu, popuFit, popuPower] = environmental_selection(parent, parentFit, parentPower, child, childFit, childPower, keep)
allPopu = [parent; child];
allFit = [parentFit; childFit];
allPower = [parentPower; childPower];
[~, order] = sort(allFit, 'descend');

N = size(parent, 1);
keep = min(N, keep);
pick = [order(1 : keep); order(keep + randperm(numel(order) - keep, N - keep))];
pick = pick(1 : N);

[popuFit, id] = sort(allFit(pick), 'descend');
pick = pick(id);
popu = allPopu(pick, :);
popuPower = allPower(pick, :);
end

%% Utility functions
function pressure = social_pressure(popu, field)
site = round(popu(:));
site = site(site >= 1 & site <= field);
count = accumarray(site, 1, [field, 1]);
p = count(count > 0) / numel(site);
entropy = -sum(p .* log(p)) / log(min(field, numel(site)));
pressure = 1 - min(max(entropy, 0), 1);
end

function stagnation = stagnation_update(nowBest, lastBest, stagnation)
if nowBest > lastBest
    stagnation = 0;
else
    stagnation = stagnation + 1;
end
end

function rareSite = rare_site(popu, site)
count = accumarray(round(popu(:)), 1, [max(site), 1]);
siteCount = count(site);
rareSite = site(siteCount < mean(siteCount));
end

function weakSite = weak_part(popuPower, layout, D)
weakSite = popuPower(ismember(popuPower, layout));
if isempty(weakSite)
    weakSite = layout(randperm(D));
end
end

function layout = complete_layout(layout, sitePool, site, D, randRate)
layout = unique(round(layout(:)'), 'stable');
sitePool = intersect(unique(round(sitePool(:)'), 'stable'), site, 'stable');
while numel(layout) < D
    candidate = setdiff(sitePool, layout, 'stable');
    if isempty(candidate) || rand < randRate
        candidate = setdiff(site, layout, 'stable');
    end
    layout(end + 1) = candidate(randi(numel(candidate))); %#ok<AGROW>
end
layout = layout(1 : D);
end

function x = legal(x, wf)
x = unique(round(x(:)'), 'stable');
x = x(x >= 1 & x <= wf.rows * wf.cols);
x = setdiff(x, wf.NA_loc, 'stable');
end

function key = layout_key(popu)
key = unique(sort(round(popu), 2), 'rows', 'stable');
end

function [popu, evaluated] = remove_seen(popu, evaluated)
key = sort(round(popu), 2);
[~, id] = unique(key, 'rows', 'stable');
popu = popu(id, :);
key = key(id, :);
seen = ismember(key, evaluated, 'rows');
popu = popu(~seen, :);
evaluated = [evaluated; key(~seen, :)];
end

function popu = unique_inherit(popu, N, D, sourceBest, weakSite, extraD, site)
while true
    [~, id] = unique(sort(round(popu), 2), 'rows', 'stable');
    popu = popu(id, :);
    if size(popu, 1) >= N
        popu = popu(1 : N, :);
        return;
    end
    dropNum = randi([0, max(0, extraD)]);
    inheritedSite = setdiff(sourceBest, weakSite(1 : dropNum), 'stable');
    popu(end + 1, :) = complete_layout(inheritedSite, site, site, D, 1 / D); 
end
end
