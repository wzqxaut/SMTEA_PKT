clear;
clc;
tic;
format long
algo_path = fileparts(mfilename('fullpath'));
problem_path = fullfile(algo_path, '..', 'WindFarmOptimization');
ws_path = fullfile(problem_path, 'windscenarios');
save_path = fullfile(algo_path, '..', 'Results');
addpath(algo_path)
addpath(problem_path)
addpath(ws_path)
runTime = 21;
popsize = 50;
iterations = 200;
rows = 21;
cols = 21;
cell_width = 77.0 * 3;
turbine_num = [40, 35, 30];
NA_type_list = 0; 
n_speeds = [3, 3, 4, 4, 3, 6, 3, 3]; 
n_directions = [12, 9, 12, 10, 8, 12, 10, 12]; 
unifrom = [0, 0, 0, 0, 0, 0, 1, 1];
problem_list = 8;
for wt = 1:problem_list
    for NA_type = NA_type_list
        NA_loc_array = gene_NA_loc(NA_type);
        [wf, ws_folder] = gene_windfram(rows, cols, turbine_num, cell_width, NA_loc_array, n_speeds(wt), n_directions(wt), unifrom(wt),wt);
        for num = 1 : length(turbine_num)
            folder{num} = fullfile(save_path, ws_folder, sprintf('tn%d', turbine_num(num)));
            if ~exist(folder{num}, 'dir')
                mkdir(folder{num})
            end
        end
        K = max(size(wf.turbine_num)); 
        eta = zeros(iterations, K, runTime); 
        fitness = zeros(runTime, K); 
        farmlayout = zeros(K, runTime, wf.cols * wf.rows);
        for t = 1 : runTime
            begin_time = tic;
            [BestChart, BestFitness, temp_farmlayout] =SMTEA_PKT(popsize, wf, iterations);
            for k = 1 : K
                eta(:, k, t) = BestChart(:, k);
                fitness(t, k) = BestFitness(k);
                farmlayout(k, t, :) = temp_farmlayout(k, :);
            end
            end_t = toc(begin_time);
            cost_t = seconds(end_t);
            cost_t.Format = 'hh:mm:ss';
            fprintf('problem: %d, runtime: %d, Cost Times: %s  \n', wt, t, cost_t); 
        end
        for k = 1 : K  
            result = cell(1, 3); 
            result{1} = squeeze(eta(:, k, :));
            result{2} = squeeze(fitness(:, k));
            result{3} = squeeze(farmlayout(k, :, :));
            save(fullfile(folder{k}, 'result.mat'), 'result');
        end
    end
end
