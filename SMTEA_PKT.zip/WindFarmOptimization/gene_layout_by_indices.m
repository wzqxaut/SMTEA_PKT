%------------------------------- Reference --------------------------------
% @Article{Li2025BDE,
%   title    = {Discrete bi-population differential evolution for optimizing complex wind farm layouts in diverse terrains},
%   author   = {Li, Jiayi and Zhang, Zihang and Zheng, Tao and Tang, Jun and Lei, Zhenyu and Gao, Shangce},
%   journal  = {Energy},
%   volume   = {335},
%   year     = {2025},
%   pages    = {137885},
%   doi      = {10.1016/j.energy.2025.137885},
% }
%-------------------------------------------------------------------------

function [framlayout] = gene_layout_by_indices(wf,pop)
        pop_size = size(pop,1);
        framlayout = zeros(pop_size, wf.rows*wf.cols);
        for i =1:pop_size
            framlayout(i, pop(i, :)) = 1;
        end
end