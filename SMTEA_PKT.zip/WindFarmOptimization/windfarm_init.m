%------------------------------- Reference --------------------------------
% @Article{Li2025BDE,
%   title    = {Discrete bi-population differential evolution for optimizing complex wind farm layouts in diverse terrains},
%   author   = {Li, Jiayi and Zhang, Zihang and Zheng, Tao and Tang, Jun and Lei, Zhenyu and Gao, Shangce},
%   journal  = {Energy},
%   volume   = {335},
%   year     = {2025},
%   pages    = {137885},
%   doi      = {10.1016/j.energy.2025.137885},
% }
%-------------------------------------------------------------------------

function [pop_indices, lu, popuFitness_sortindex, power_order_sortindex, lp_power_accum_sortindex] = windfarm_init(popsize, turbine_num, wf, taskid)
C = cell(1, 6);
C{1} = [1 : 21, 211 : 231, 421 : 441]; %南北
C{2} = [11 : 21, 42 : 21 : 231, 211 : 21 : 400, 421 : 431, 1 : 22 : 441]; %东北,西南
C{3} = [1 : 21 : 421, 11 : 21 : 431, 21 : 21 : 441]; %东西
C{4} = [231 : 21 : 441, 431 : 440, 1 : 11, 22 : 21 : 211, 21 : 20 : 421]; %东南，西北
C{5} = [1 : 21, 421 : 441, 22 : 21 : 400, 42 : 21 : 420]; %%四面
C{6} = [1 : 441];
for k = 1 : length(C)
    for i = 1 : popsize
        n = length(C{k});
        indices_front = max(1, floor(turbine_num * 0.6));
        w = ones(1, n); % 初始权重
        selected = zeros(1, indices_front);
        available = true(1, n); % 是否可选
        for j = 1 : indices_front
            w_use = w;
            w_use(~available) = 0;
            w_use = w_use / sum(w_use); % 归一化
            idx = find(rand <= cumsum(w_use), 1);
            selected(j) = C{k}(idx);
            % 禁止重复
            available(idx) = false;
            w(idx) = 0;
            % 降低相邻概率（软约束）
            if idx > 1
                w(idx - 1) = w(idx - 1) * 0.1;
            end
            if idx < n
                w(idx + 1) = w(idx + 1) * 0.1;
            end
        end
        %按照风向取出前一半个元素
        pop_indices_front = selected;
        pop_indices_all = setdiff(C{6}, pop_indices_front);
        pop_indices_end = pop_indices_all(randperm(length(pop_indices_all), turbine_num - length(selected)));
        pop_indices_temp((k - 1) * popsize + i, :) = [pop_indices_front, pop_indices_end];
    end
end
[popuFitness, power_order, lp_power_accum] = wf_fitness(wf, pop_indices_temp, taskid);
[~, sortindex] = sort(-popuFitness);
index = sortindex(1 : popsize);
index = index(randperm(length(index)));
pop_indices = pop_indices_temp(index, :);
popuFitness_sortindex = popuFitness(index, :);
power_order_sortindex = power_order(index, :);
lp_power_accum_sortindex = lp_power_accum(index, :);
lu = [1 * ones(1, turbine_num); wf.rows * wf.cols * ones(1, turbine_num)];
% index =1:wf.rows* wf.cols;
% index(wf.NA_loc)=[];
% rand_index = randperm(length(index));
% index = index(rand_index);
% pop_indices = zeros(popsize, turbine_num);
% for i = 1: popsize
%     rand_index = randperm(length(index));
%     index = index(rand_index);
%     pop_indices(i, :) = index(1:turbine_num);
% end
% lu = [1 * ones(1, turbine_num); wf.rows* wf.cols * ones(1, turbine_num)];
% [popuFitness, power_order, lp_power_accum] = wf_fitness(wf, pop_indices, taskid);
% [~, sortindex] = sort(-popuFitness);
% index = sortindex(1 : 100);
% index = index(randperm(length(index)));
% pop_indices = pop_indices(index, :);
% popuFitness_sortindex = popuFitness(index, :);
% power_order_sortindex = power_order(index, :);
% lp_power_accum_sortindex = lp_power_accum(index, :);
end
