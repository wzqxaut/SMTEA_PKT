%------------------------------- Reference --------------------------------
% @Article{Li2025BDE,
%   title    = {Discrete bi-population differential evolution for optimizing complex wind farm layouts in diverse terrains},
%   author   = {Li, Jiayi and Zhang, Zihang and Zheng, Tao and Tang, Jun and Lei, Zhenyu and Gao, Shangce},
%   journal  = {Energy},
%   volume   = {335},
%   year     = {2025},
%   pages    = {137885},
%   doi      = {10.1016/j.energy.2025.137885},
% }
%-------------------------------------------------------------------------

function save_results(farmlayout,farmlayout_NA,i,folder)

save(sprintf('%s/farmlayout%d.mat',folder,i),"farmlayout")
save(sprintf('%s/farmlayoutNA%d.mat',folder,i),"farmlayout_NA")

end
