function pop = binary_to_indices(framlayout)
    pop_size = size(framlayout,1);
    turbine_num = sum(framlayout(1,:)); 
    pop = zeros(pop_size, turbine_num);
    for i = 1:pop_size
        idx = find(framlayout(i,:) == 1);
        pop(i,:) = idx;
    end
    for i = 1:size(pop,1)
        pop(i,:) = pop(i, randperm(size(pop,2)));
    end
end
