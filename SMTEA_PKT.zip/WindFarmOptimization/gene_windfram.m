%------------------------------- Reference --------------------------------
% @Article{Li2025BDE,
%   title    = {Discrete bi-population differential evolution for optimizing complex wind farm layouts in diverse terrains},
%   author   = {Li, Jiayi and Zhang, Zihang and Zheng, Tao and Tang, Jun and Lei, Zhenyu and Gao, Shangce},
%   journal  = {Energy},
%   volume   = {335},
%   year     = {2025},
%   pages    = {137885},
%   doi      = {10.1016/j.energy.2025.137885},
% }
%-------------------------------------------------------------------------

function [wf,ws_folder] = gene_windfram(rows,cols,turbine_num,cell_width,NA_loc,n_speeds,n_directions,unifrom,wt)
format long
    wf.rows = rows;
    wf.cols = cols;
    wf.turbine_num = turbine_num;
    wf.cell_width = cell_width;
    wf.cell_width_half = cell_width *0.5;
    wf.NA_loc = NA_loc;
    
   
    turbine.hub_height = 80.0;
    turbine.rator_diameter = 77.0;
    turbine.surface_roughness = 0.25 * 0.001;
    turbine.rator_radius = turbine.rator_diameter / 2;
    turbine.entrainment_const = 0.5 / log(turbine.hub_height / turbine.surface_roughness);
    

    wf.turbine= turbine;
    
     if unifrom
        ws_folder = sprintf('%dspeed_%ddirection_uniform',n_speeds,n_directions);
    else
        ws_folder = sprintf('%dspeed_%ddirection',n_speeds,n_directions);
    end
    
    ws = load([ws_folder,'.mat']);

    wf.theta = ws.theta;
    wf.velocity = ws.velocity; %速度
    wf.f_theta_v =ws.f_theta_v;  %概率
    

    wf = cal_P_rate_total(wf);
end



function wf = cal_P_rate_total(wf)
    f_p = 0.0;
    for ind_t =1:length(wf.theta)
        for ind_v = 1 :length(wf.velocity)
            f_p = f_p+ wf.f_theta_v(ind_t, ind_v) * P_i_X(wf.velocity(ind_v));
        end
    end
    wf.power_total = wf.turbine_num * f_p;  %理论输出总功率 
end



function re= P_i_X(v)   %输出功率
    if v < 2.0
        re= 0;
    elseif v < 12.8
        re =  0.3 * v ^ 3;
    elseif v < 18
        re = 629.1;
    else
        re = 0;
    end
end


