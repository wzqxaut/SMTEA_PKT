function [population_new] = repalce_worst(population,power_order,wf,repalce_rate)
    popsize = size(population,1);
    dim = size(population,2);
    for i = 1:popsize
        matrix = zeros(wf.rows, wf.cols);
        pos = power_order(i,floor(dim/repalce_rate):end);
        pos_loc=wf.NA_loc;
        for k = 1:length(pos)
            r = ceil(pos(k) / wf.cols);
            c = mod(pos(k)-1, wf.cols) + 1;
            matrix(r, c) = 1;
        end
        for k = 1:length(pos_loc)
            r = ceil(pos_loc(k) / wf.cols);
            c = mod(pos_loc(k)-1, wf.cols) + 1;
            matrix(r, c) = 2;
        end
        pos = flip(pos);
        R = 3; % 邻域半径
        for j = 1:(dim-length(pos))
            r0 = ceil(pos(j) / wf.cols);
            c0 = mod(pos(j)-1, wf.cols) + 1;
            r_range = max(1, r0-R):min(wf.rows, r0+R);
            c_range = max(1, c0-R):min(wf.cols, c0+R);
            candidate = [];
            for rr = r_range
                for cc = c_range
                    if matrix(rr,cc) == 0
                        candidate = [candidate; rr, cc];
                    end
                end
            end
            if isempty(candidate)
                continue;
            end
            idx = randi(size(candidate,1));
            new_r(j) = candidate(idx,1);
            new_c(j) = candidate(idx,2);
            matrix(new_r(j),new_c(j)) = 1;
        end
        v = reshape(matrix', 1, []);
        population_new(i,:)=binary_to_indices(reshape(matrix', 1, []));
    end
end
